"""
Created on 11 de mar. de 2026

@author: robertodias
"""
import cv2
import numpy as np
from pathlib import Path
from deepface import DeepFace
import warnings
import unicodedata
from PIL import Image
from PIL import ImageDraw, ImageFont
import os
import sys
import logging

# CONFIGURAÇÕES PARA SUPRIMIR TODOS OS WARNINGS
# ==============================================

# Suprimir todos os warnings do Python
warnings.filterwarnings('ignore')

# Configurar variáveis de ambiente para TensorFlow
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'  # 0=debug, 1=info, 2=warning, 3=error
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'  # Desabilita oneDNN custom operations
os.environ['GLOG_minloglevel'] = '3'  # Suprime logs do Google
os.environ['OPENCV_LOG_LEVEL'] = 'ERROR'  # Suprime warnings do OpenCV
os.environ['TF_CPP_MIN_VLOG_LEVEL'] = '3'  # Suprime logs verbosos do TensorFlow

# Suprimir logs do TensorFlow
logging.getLogger('tensorflow').setLevel(logging.ERROR)
logging.getLogger('absl').setLevel(logging.ERROR)
logging.getLogger('keras').setLevel(logging.ERROR)

# Redirecionar stderr para null temporariamente
stderr_temp = sys.stderr
sys.stderr = open(os.devnull, 'w')

# Importar TensorFlow com warnings suprimidos
try:
    import tensorflow as tf
    tf.get_logger().setLevel('ERROR')
    tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)
except:
    pass

# Restaurar stderr
sys.stderr.close()
sys.stderr = stderr_temp

# Configurar OpenCV
try:
    cv2.setNumThreads(0)
except:
    pass

def remover_acentos(texto):
    """
    Remove acentos e normaliza caracteres especiais.
    
    Args:
        texto (str): Texto original com acentos
        
    Returns:
        str: Texto normalizado sem acentos
    """
    if not isinstance(texto, str):
        return texto
    
    # Normalizar para forma NFD (decompor caracteres acentuados)
    texto_normalizado = unicodedata.normalize('NFD', texto)
    # Filtrar apenas caracteres sem acentos (remover diacríticos)
    texto_sem_acento = ''.join(c for c in texto_normalizado if unicodedata.category(c) != 'Mn')
    return texto_sem_acento

def carregar_imagem_seguro(caminho_imagem):
    """
    Tenta carregar uma imagem usando múltiplos métodos.
    
    Args:
        caminho_imagem (Path): Caminho da imagem
        
    Returns:
        numpy.ndarray or None: Imagem carregada ou None se falhar
    """
    caminho_str = str(caminho_imagem)
    
    # Método 1: PIL (recomendado para evitar problemas com caracteres especiais)
    try:
        pil_image = Image.open(caminho_str)
        # Converter PIL para OpenCV (RGB para BGR)
        imagem = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
        return imagem
    except Exception:
        pass
    
    # Método 2: OpenCV com decode
    try:
        imagem_array = np.fromfile(caminho_str, dtype=np.uint8)
        imagem = cv2.imdecode(imagem_array, cv2.IMREAD_COLOR)
        if imagem is not None:
            return imagem
    except Exception:
        pass
    
    return None

def colocar_texto_com_acentos(img, texto, posicao, tamanho=32, cor=(255, 255, 255)):
    """
    Coloca texto com acentos na imagem usando PIL.
    
    Args:
        img: Imagem OpenCV
        texto (str): Texto a ser escrito
        posicao (tuple): Posição (x, y) do texto
        tamanho (int): Tamanho da fonte
        cor (tuple): Cor do texto em BGR
        
    Returns:
        Imagem com texto
    """
    # Converter OpenCV BGR para PIL RGB
    img_pil = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(img_pil)
    
    # Tentar usar fonte que suporta acentos
    try:
        # Tentar fontes comuns no Windows
        font = ImageFont.truetype("arial.ttf", tamanho)
    except:
        try:
            font = ImageFont.truetype("C:/Windows/Fonts/Arial.ttf", tamanho)
        except:
            try:
                font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", tamanho)
            except:
                # Fallback para fonte padrão (pode não suportar acentos)
                font = ImageFont.load_default()
    
    # Desenhar texto
    draw.text(posicao, texto, font=font, fill=(cor[2], cor[1], cor[0]))  # RGB
    
    # Converter de volta para OpenCV BGR
    return cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)

def exibir_imagem_com_resultado(imagem, nome_pessoa, raca, confianca, probabilidades):
    """
    Exibe a imagem em uma janela com os resultados sobrepostos.
    
    Args:
        imagem: Imagem OpenCV
        nome_pessoa (str): Nome da pessoa
        raca (str): Raça dominante
        confianca (float): Confiança facial
        probabilidades (dict): Probabilidades por raça
    """
    # Criar cópia da imagem
    img_display = imagem.copy()
    
    # Redimensionar se necessário
    altura, largura = img_display.shape[:2]
    if largura > 800:
        escala = 800 / largura
        nova_largura = 800
        nova_altura = int(altura * escala)
        img_display = cv2.resize(img_display, (nova_largura, nova_altura))
    
    # Converter para PIL para texto com acentos
    img_pil = Image.fromarray(cv2.cvtColor(img_display, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(img_pil)
    
    # Tentar carregar fonte que suporta acentos
    try:
        font_titulo = ImageFont.truetype("arial.ttf", 24)
        font_texto = ImageFont.truetype("arial.ttf", 18)
    except:
        try:
            font_titulo = ImageFont.truetype("C:/Windows/Fonts/Arial.ttf", 24)
            font_texto = ImageFont.truetype("C:/Windows/Fonts/Arial.ttf", 18)
        except:
            font_titulo = ImageFont.load_default()
            font_texto = ImageFont.load_default()
    
    # Cabeçalho com nome e raça
    cabecalho = f"{nome_pessoa} - {raca} ({confianca:.2%})"
    
    # Desenhar fundo preto para o cabeçalho
    bbox = draw.textbbox((0, 0), cabecalho, font=font_titulo)
    texto_largura = bbox[2] - bbox[0]
    texto_altura = bbox[3] - bbox[1]
    
    # Desenhar retângulo preto semi-transparente
    overlay = Image.new('RGBA', img_pil.size, (0, 0, 0, 0))
    overlay_draw = ImageDraw.Draw(overlay)
    overlay_draw.rectangle([(10, 10), (10 + texto_largura + 20, 10 + texto_altura + 20)], 
                          fill=(0, 0, 0, 180))
    
    # Combinar overlay com imagem
    img_pil = Image.alpha_composite(img_pil.convert('RGBA'), overlay).convert('RGB')
    draw = ImageDraw.Draw(img_pil)
    
    # Desenhar texto do cabeçalho
    draw.text((20, 15), cabecalho, font=font_titulo, fill=(255, 255, 255))
    
    # Fundo para probabilidades
    y_prob = 70
    overlay_prob = Image.new('RGBA', img_pil.size, (0, 0, 0, 0))
    overlay_prob_draw = ImageDraw.Draw(overlay_prob)
    overlay_prob_draw.rectangle([(10, y_prob - 10), (300, y_prob + 140)], 
                               fill=(0, 0, 0, 180))
    
    # Combinar overlay de probabilidades
    img_pil = Image.alpha_composite(img_pil.convert('RGBA'), overlay_prob).convert('RGB')
    draw = ImageDraw.Draw(img_pil)
    
    # Desenhar probabilidades (com acentos preservados)
    draw.text((20, y_prob), "Probabilidades:", font=font_texto, fill=(255, 255, 255))
    
    for i, (raca_item, porcentagem) in enumerate(sorted(probabilidades.items(), key=lambda x: x[1], reverse=True)):
        texto_prob = f"{raca_item}: {porcentagem:.2f}%"
        draw.text((20, y_prob + 30 + i*25), texto_prob, font=font_texto, fill=(255, 255, 255))
    
    # Converter de volta para OpenCV
    img_display = cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
    
    # Mostrar imagem
    janela_nome = "Análise Facial"
    cv2.imshow(janela_nome, img_display)
    cv2.moveWindow(janela_nome, 100, 100)
    
    print("\n⏎ Pressione qualquer tecla na janela da imagem para continuar...")
    print("   (Ou pressione ESC para sair)")

# Pasta onde as imagens estão localizadas
pasta_imagens = Path(r"C:\Imagem")

# Verificar se a pasta existe
if not pasta_imagens.exists():
    print(f"ERRO: A pasta {pasta_imagens} não existe!")
    print("Criando pasta...")
    pasta_imagens.mkdir(parents=True, exist_ok=True)
    print(f"Pasta {pasta_imagens} criada. Coloque as imagens nela e execute novamente.")
    exit(1)

# Extensões de arquivo de imagem suportadas
extensoes_imagem = [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff"]
extensoes_imagem += [ext.upper() for ext in extensoes_imagem]

# Coletar todas as imagens
caminhos_imagens = []
for extensao in extensoes_imagem:
    caminhos_imagens.extend(pasta_imagens.glob(f"*{extensao}"))

# Remover duplicatas
caminhos_unicos = []
nomes_vistos = set()
for caminho in caminhos_imagens:
    if caminho.name not in nomes_vistos:
        nomes_vistos.add(caminho.name)
        caminhos_unicos.append(caminho)

if not caminhos_unicos:
    print(f"Nenhuma imagem encontrada na pasta: {pasta_imagens}")
    print("Arquivos encontrados na pasta:")
    for arquivo in pasta_imagens.iterdir():
        print(f"  - {arquivo.name}")
    exit(1)

print(f"Encontradas {len(caminhos_unicos)} imagens para processar.\n")

# Processar cada imagem
resultados = []

for idx, imagem_path in enumerate(caminhos_unicos, 1):
    print(f"\n{'='*60}")
    print(f"Processando imagem {idx}/{len(caminhos_unicos)}: {imagem_path.name}")
    print(f"{'='*60}")
    
    try:
        # Carregar a imagem
        imagem = carregar_imagem_seguro(imagem_path)
        
        if imagem is None:
            print(f"❌ ERRO: Não foi possível carregar a imagem: {imagem_path.name}")
            continue
        
        print(f"✅ Imagem carregada: {imagem.shape}")
        
        # Extrair e processar nome
        nome_pessoa = remover_acentos(imagem_path.stem)
        nome_pessoa = nome_pessoa.replace('_', ' ').strip()
        nome_pessoa = ' '.join(nome_pessoa.split())
        print(f"👤 Nome: {nome_pessoa}")
        
        # Analisar com DeepFace
        print("🔍 Analisando com DeepFace...")
        
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            resultado = DeepFace.analyze(
                img_path=imagem, 
                actions=["race"], 
                enforce_detection=False,
                silent=True
            )
        
        # Processar resultado
        if isinstance(resultado, list) and resultado:
            face_data = resultado[0]
            
            raca_dominante = face_data.get("dominant_race", "Não identificado")
            confianca = face_data.get("face_confidence", 0)
            racas = face_data.get("race", {})
            
            # Corrigir "indigena" para "indígena" com acento
            if "indigena" in racas and "indígena" not in racas:
                racas["indígena"] = racas.pop("indigena")
            if raca_dominante == "indigena":
                raca_dominante = "indígena"
            
            # Armazenar resultado
            resultados.append({
                'nome': nome_pessoa,
                'arquivo': imagem_path.name,
                'raca_dominante': raca_dominante,
                'confianca': confianca,
                'probabilidades': racas,
                'imagem': imagem
            })
            
            # Exibir resultados no console
            print(f"\n📊 RESULTADOS:")
            print(f"  🏆 Raça Dominante: {raca_dominante}")
            print(f"  📈 Confiança Facial: {confianca:.4f}")
            print(f"\n  📊 Probabilidades:")
            for raca, porcentagem in sorted(racas.items(), key=lambda x: x[1], reverse=True):
                print(f"    {raca:10}: {porcentagem:6.2f}%")
            
            # EXIBIR IMAGEM COM RESULTADOS
            exibir_imagem_com_resultado(imagem, nome_pessoa, raca_dominante, confianca, racas)
            
            # Aguardar tecla
            key = cv2.waitKey(0) & 0xFF
            cv2.destroyAllWindows()
            
            if key == 27:  # ESC
                print("\n⏹️ Processamento interrompido pelo usuário.")
                break
            
        else:
            print(f"❌ Erro: Resultado inválido para {imagem_path.name}")
            
    except Exception as e:
        print(f"❌ Erro ao processar {imagem_path.name}: {str(e)}")

# Resumo final
print(f"\n{'='*60}")
print(f"✅ PROCESSAMENTO CONCLUÍDO!")
print(f"{'='*60}")
print(f"Total de imagens processadas: {len(resultados)}/{len(caminhos_unicos)}")

if resultados:
    print(f"\n📋 RESUMO DOS RESULTADOS:")
    print("-" * 40)
    for r in resultados:
        print(f"👤 {r['nome']}: {r['raca_dominante']} ({r['confianca']:.2%})")
    
    # Estatísticas
    racas_encontradas = {}
    for r in resultados:
        raca = r['raca_dominante']
        racas_encontradas[raca] = racas_encontradas.get(raca, 0) + 1
    
    print(f"\n📊 DISTRIBUIÇÃO POR RAÇA:")
    for raca, quantidade in racas_encontradas.items():
        percentual = (quantidade / len(resultados)) * 100
        print(f"  {raca}: {quantidade} pessoa(s) ({percentual:.1f}%)")

print(f"\n{'='*60}")
cv2.destroyAllWindows()